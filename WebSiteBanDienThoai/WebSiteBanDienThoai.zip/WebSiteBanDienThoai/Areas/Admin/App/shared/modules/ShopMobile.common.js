﻿(function () {
    angular.module('AdmShopMobile.common', ['angularUtils.directives.dirPagination', 'ui.router', 'toastr'])
})();